# Mini-challenge-team05
# 🏆 Team 05

---
## 👥 Team Members

- **이름**: 박주원
- **학번**: 20232500
- **GitHub**: [JUWON PARK](https://github.com/parkj00won)

---

- **이름**: 서유민
- **학번**: 20242517
- **GitHub**: [carvestar](https://github.com/carvestar)

---

- **이름**: 임준현
- **학번**: 20251272
- **GitHub**:[JUNHYUN IM](https://github.com/wnsgus-the-creator)

---

- **이름**: 주혜림 
- **학번**: 20251266
- **GitHub**: [Ju-06](https://github.com/Ju-06)

---
