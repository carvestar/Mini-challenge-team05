package com.cookandroid.myapp;
// 앱 시작 타이틀 화면 기능 넣어주세요. (3초후 메인으로 이동)
public class SplashActivity {
}
