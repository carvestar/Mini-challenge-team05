package com.cookandroid.myapp;
//식재료 1개 디자인 (리스트-RecyclerView 아이템)
public class FoodAdapter {
}
